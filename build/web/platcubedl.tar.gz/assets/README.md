cd $HOME\Desktop\PlatCubeDL
.\.venv\Scripts\Activate.ps1
python main.py